# Gumroad listing draft — HomeRoom

## Title
Homeschool Planner — Lesson Plans, Attendance & Gradebook Tracker

## Permalink
`homeschool-planner-lessons-attendance-gradebook`

## Price
$0 (free tool)

## Description
**The homeschool planner that stays out of your way.** HomeRoom is the offline lesson planner for homeschool families — plan the week, take attendance in one tap, and keep grades without a spreadsheet or a subscription.

**What's inside:**
- 📅 Weekly lesson planner — per child, per subject, with week-by-week navigation
- ✅ Today's view — every lesson due today with done checkboxes
- 🖐️ One-tap attendance — present/absent per child per day, year totals + rates (180-day tracking)
- 🎓 Gradebook — assignments with auto percentages + letter grades, per-subject averages
- 📚 Reading log — books, authors, pages, finish dates per child
- 👨‍👩‍👧 Multi-child built in — custom subjects per student
- 🌙 Dark mode, works on phone/tablet/computer

**Private by design:** 100% offline single HTML file. No account, no subscription, no tracking — your family's data never leaves your device. Export a JSON backup any time. Print a clean summary for your records.

**More by Glenerds:** families also use [GradePlan](https://glenerds.gumroad.com) — grade & GPA planning — and [HomeInventory](https://glenerds.gumroad.com) — catalog everything in your home. Find them all in the Glenerds store: https://glenerds.gumroad.com

Free forever — by Glenerds. https://glenerds.gumroad.com

*If you were ever charged for this product, contact us for a full refund — HomeRoom is and always will be free.*

## Thumbnail/gallery
Thumbnail: `gallery/cover-square-1200.png` (verified present). Square cover + gallery screenshots from `gallery/` (today view, weekly planner, attendance, gradebook, dark mode, mobile).
